package com.clipcutter.app

import android.app.*
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.content.LocalBroadcastManager
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.ceil
import kotlin.math.min

/**
 * Foreground service that cuts one long video into many clips, one at a time.
 *
 * Design notes for stability on 2-5 hour videos:
 *  - Clips are produced strictly one-by-one (never in parallel, never buffered
 *    fully in RAM) so memory use stays flat regardless of source length.
 *  - Each clip is written first to the app's own cache directory (a plain
 *    file path FFmpeg can seek in), then copied into MediaStore. The cache
 *    file is deleted immediately after the copy so disk usage never exceeds
 *    roughly one clip's size.
 *  - When the requested ratio is "Original" we use stream copy (-c copy),
 *    which does not decode/re-encode the video at all: fast and very low
 *    memory. Any crop ratio forces re-encoding only for that clip's short
 *    duration, never the whole file.
 *  - The whole job runs as a foreground service with a persistent
 *    notification, which stops Android from killing the process while the
 *    screen is off or the app is backgrounded.
 */
class CutterService : Service() {

    companion object {
        const val ACTION_START = "com.clipcutter.app.START"
        const val ACTION_CANCEL = "com.clipcutter.app.CANCEL"
        const val ACTION_PROGRESS = "com.clipcutter.app.PROGRESS"
        const val ACTION_DONE = "com.clipcutter.app.DONE"
        const val ACTION_ERROR = "com.clipcutter.app.ERROR"

        const val EXTRA_URI = "extra_uri"
        const val EXTRA_DURATION_MS = "extra_duration_ms"
        const val EXTRA_BY_DURATION = "extra_by_duration"
        const val EXTRA_SECONDS_PER_CLIP = "extra_seconds_per_clip"
        const val EXTRA_CLIP_COUNT = "extra_clip_count"
        const val EXTRA_RATIO = "extra_ratio"

        const val EXTRA_CURRENT = "extra_current"
        const val EXTRA_TOTAL = "extra_total"
        const val EXTRA_PERCENT = "extra_percent"
        const val EXTRA_ERROR = "extra_error"

        private const val CHANNEL_ID = "clipcutter_channel"
        private const val NOTIF_ID = 1001
    }

    private val cancelled = AtomicBoolean(false)
    private var workerThread: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> {
                cancelled.set(true)
                FFmpegKit.cancel()
            }
            ACTION_START -> startJob(intent)
        }
        return START_NOT_STICKY
    }

    private fun startJob(intent: Intent) {
        createChannel()
        val notification = buildNotification("Starting…", 0, 1)
        startForeground(NOTIF_ID, notification)
        cancelled.set(false)

        val uri = intent.getParcelableExtra<Uri>(EXTRA_URI) ?: run {
            broadcastError("No video selected")
            stopSelf()
            return
        }
        val durationMs = intent.getLongExtra(EXTRA_DURATION_MS, 0L)
        val byDuration = intent.getBooleanExtra(EXTRA_BY_DURATION, true)
        val secondsPerClip = intent.getIntExtra(EXTRA_SECONDS_PER_CLIP, 60)
        val clipCount = intent.getIntExtra(EXTRA_CLIP_COUNT, 10)
        val ratio = intent.getStringExtra(EXTRA_RATIO) ?: "Original"

        workerThread = Thread {
            try {
                runCutting(uri, durationMs, byDuration, secondsPerClip, clipCount, ratio)
            } catch (e: Exception) {
                broadcastError(e.message ?: "Unknown error while cutting")
            } finally {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        workerThread?.start()
    }

    private fun runCutting(
        uri: Uri,
        durationMs: Long,
        byDuration: Boolean,
        secondsPerClip: Int,
        clipCount: Int,
        ratio: String
    ) {
        val totalSeconds = durationMs / 1000.0

        val (clipLenSec, count) = if (byDuration) {
            val len = secondsPerClip.toDouble()
            val cnt = ceil(totalSeconds / len).toInt().coerceAtLeast(1)
            Pair(len, cnt)
        } else {
            val cnt = clipCount.coerceAtLeast(1)
            val len = totalSeconds / cnt
            Pair(len, cnt)
        }

        // "saf:" pipe lets FFmpeg read directly from a content:// Uri without
        // us ever copying the multi-hour source file into app storage first.
        val safInput = FFmpegKitConfig.getSafParameterForRead(this, uri)

        val outDir = File(cacheDir, "clipcutter_tmp").apply { mkdirs() }
        val timestamp = System.currentTimeMillis()

        for (i in 0 until count) {
            if (cancelled.get()) break

            val start = i * clipLenSec
            val len = min(clipLenSec, totalSeconds - start)
            if (len <= 0.3) break // ignore a near-zero leftover sliver

            val outFile = File(outDir, "clip_${timestamp}_${i + 1}.mp4")
            val cmd = buildCommand(safInput, start, len, ratio, outFile.absolutePath)

            updateNotification("Cutting clip ${i + 1} of $count", i, count)
            broadcastProgress(i, count, (i * 100) / count)

            val session = FFmpegKit.execute(cmd)
            if (!ReturnCode.isSuccess(session.returnCode)) {
                if (cancelled.get()) break
                broadcastError("Failed on clip ${i + 1}: ${session.failStackTrace ?: session.state}")
                outFile.delete()
                continue
            }

            saveToMediaStore(outFile, "ClipCutter_${timestamp}_${i + 1}.mp4")
            outFile.delete()

            broadcastProgress(i + 1, count, ((i + 1) * 100) / count)
        }

        outDir.deleteRecursively()

        if (!cancelled.get()) {
            val savedCount = count
            broadcastDone(savedCount)
        }
    }

    private fun buildCommand(
        safInput: String,
        startSec: Double,
        lenSec: Double,
        ratio: String,
        outPath: String
    ): String {
        val ss = String.format("%.2f", startSec)
        val t = String.format("%.2f", lenSec)

        return if (ratio == "Original") {
            // Stream copy: no decode/encode, near-instant, minimal CPU/RAM.
            "-ss $ss -t $t -i \"$safInput\" -c copy -avoid_negative_ts make_zero \"$outPath\""
        } else {
            val filter = cropFilterFor(ratio)
            // Re-encode only this short clip, not the whole source file.
            "-ss $ss -i \"$safInput\" -t $t -vf \"$filter\" -c:v libx264 -preset veryfast " +
                "-crf 23 -c:a aac -b:a 128k \"$outPath\""
        }
    }

    private fun cropFilterFor(ratio: String): String = when (ratio) {
        "9:16" -> "crop='min(iw,ih*9/16)':'min(ih,iw*16/9)',scale=1080:1920"
        "1:1" -> "crop='min(iw,ih)':'min(iw,ih)',scale=1080:1080"
        "4:3" -> "crop='min(iw,ih*4/3)':'min(ih,iw*3/4)',scale=1440:1080"
        "16:9" -> "crop='min(iw,ih*16/9)':'min(ih,iw*9/16)',scale=1920:1080"
        else -> "crop=iw:ih"
    }

    private fun saveToMediaStore(source: File, displayName: String) {
        val resolver = contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ClipCutter")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val itemUri = resolver.insert(collection, values) ?: return

        resolver.openOutputStream(itemUri)?.use { out ->
            source.inputStream().use { input -> input.copyTo(out) }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(itemUri, values, null, null)
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Video Cutting", NotificationManager.IMPORTANCE_LOW
            )
            val mgr = getSystemService(NotificationManager::class.java)
            mgr.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String, progress: Int, max: Int): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("ClipCutter")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_slideshow)
            .setOngoing(true)
            .setProgress(max.coerceAtLeast(1), progress, false)
            .build()
    }

    private fun updateNotification(text: String, progress: Int, max: Int) {
        val mgr = getSystemService(NotificationManager::class.java)
        mgr.notify(NOTIF_ID, buildNotification(text, progress, max))
    }

    private fun broadcastProgress(current: Int, total: Int, percent: Int) {
        val intent = Intent(ACTION_PROGRESS).apply {
            putExtra(EXTRA_CURRENT, current)
            putExtra(EXTRA_TOTAL, total)
            putExtra(EXTRA_PERCENT, percent)
        }
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
    }

    private fun broadcastDone(total: Int) {
        val intent = Intent(ACTION_DONE).apply { putExtra(EXTRA_TOTAL, total) }
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
    }

    private fun broadcastError(msg: String) {
        val intent = Intent(ACTION_ERROR).apply { putExtra(EXTRA_ERROR, msg) }
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
    }
}
