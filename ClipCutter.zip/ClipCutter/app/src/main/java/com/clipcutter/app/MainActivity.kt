package com.clipcutter.app

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.LocalBroadcastManager
import androidx.core.content.LocalBroadcastManager.getInstance
import com.clipcutter.app.databinding.ActivityMainBinding
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var selectedVideoUri: Uri? = null
    private var videoDurationMs: Long = 0L
    private lateinit var prefs: SharedPreferences

    private val progressReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                CutterService.ACTION_PROGRESS -> {
                    val current = intent.getIntExtra(CutterService.EXTRA_CURRENT, 0)
                    val total = intent.getIntExtra(CutterService.EXTRA_TOTAL, 0)
                    val percent = intent.getIntExtra(CutterService.EXTRA_PERCENT, 0)
                    binding.progressBar.max = total.coerceAtLeast(1)
                    binding.progressBar.progress = current
                    binding.tvProgress.text = getString(
                        R.string.progress_format, current, total, percent
                    )
                }
                CutterService.ACTION_DONE -> {
                    setUiBusy(false)
                    val savedCount = intent.getIntExtra(CutterService.EXTRA_TOTAL, 0)
                    binding.tvProgress.text = getString(R.string.done_format, savedCount)
                    Toast.makeText(
                        this@MainActivity,
                        getString(R.string.done_toast, savedCount),
                        Toast.LENGTH_LONG
                    ).show()
                }
                CutterService.ACTION_ERROR -> {
                    setUiBusy(false)
                    val msg = intent.getStringExtra(CutterService.EXTRA_ERROR) ?: "Unknown error"
                    binding.tvProgress.text = getString(R.string.error_format, msg)
                    Toast.makeText(this@MainActivity, msg, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private val pickVideoLauncher =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                selectedVideoUri = uri
                loadVideoInfo(uri)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefs = getSharedPreferences("clipcutter_prefs", MODE_PRIVATE)

        restorePrefs()
        setupModeToggle()

        binding.btnPickVideo.setOnClickListener {
            pickVideoLauncher.launch(arrayOf("video/*"))
        }

        binding.btnCut.setOnClickListener { onCutClicked() }

        binding.btnCancel.setOnClickListener {
            val stopIntent = Intent(this, CutterService::class.java)
            stopIntent.action = CutterService.ACTION_CANCEL
            startService(stopIntent)
            setUiBusy(false)
            binding.tvProgress.text = getString(R.string.cancelled)
        }
    }

    override fun onStart() {
        super.onStart()
        LocalBroadcastManager.getInstance(this).registerReceiver(
            progressReceiver,
            IntentFilter().apply {
                addAction(CutterService.ACTION_PROGRESS)
                addAction(CutterService.ACTION_DONE)
                addAction(CutterService.ACTION_ERROR)
            }
        )
    }

    override fun onStop() {
        super.onStop()
        LocalBroadcastManager.getInstance(this).unregisterReceiver(progressReceiver)
    }

    private fun setupModeToggle() {
        binding.radioGroupMode.setOnCheckedChangeListener { _, checkedId ->
            val byDuration = checkedId == R.id.radioByDuration
            binding.etSecondsPerClip.isEnabled = byDuration
            binding.etClipCount.isEnabled = !byDuration
        }
    }

    private fun loadVideoInfo(uri: Uri) {
        val retriever = android.media.MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, uri)
            val durStr = retriever.extractMetadata(
                android.media.MediaMetadataRetriever.METADATA_KEY_DURATION
            )
            videoDurationMs = durStr?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            videoDurationMs = 0L
        } finally {
            retriever.release()
        }

        val name = queryDisplayName(uri) ?: "video"
        val h = TimeUnit.MILLISECONDS.toHours(videoDurationMs)
        val m = TimeUnit.MILLISECONDS.toMinutes(videoDurationMs) % 60
        val s = TimeUnit.MILLISECONDS.toSeconds(videoDurationMs) % 60
        binding.tvSelectedVideo.text = getString(
            R.string.selected_video_format, name, h, m, s
        )
        binding.btnCut.isEnabled = true
    }

    private fun queryDisplayName(uri: Uri): String? {
        var name: String? = null
        val cursor: Cursor? = contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            if (it.moveToFirst()) {
                val idx = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) name = it.getString(idx)
            }
        }
        return name
    }

    private fun onCutClicked() {
        val uri = selectedVideoUri
        if (uri == null) {
            Toast.makeText(this, R.string.pick_video_first, Toast.LENGTH_SHORT).show()
            return
        }
        if (videoDurationMs <= 0) {
            Toast.makeText(this, R.string.could_not_read_duration, Toast.LENGTH_SHORT).show()
            return
        }

        val byDuration = binding.radioByDuration.isChecked
        val secondsPerClip = binding.etSecondsPerClip.text.toString().toIntOrNull()
        val clipCount = binding.etClipCount.text.toString().toIntOrNull()

        if (byDuration && (secondsPerClip == null || secondsPerClip <= 0)) {
            Toast.makeText(this, R.string.enter_valid_seconds, Toast.LENGTH_SHORT).show()
            return
        }
        if (!byDuration && (clipCount == null || clipCount <= 0)) {
            Toast.makeText(this, R.string.enter_valid_count, Toast.LENGTH_SHORT).show()
            return
        }

        val ratio = binding.spinnerRatio.selectedItem.toString()

        savePrefs(byDuration, secondsPerClip, clipCount, ratio)
        setUiBusy(true)
        binding.tvProgress.text = getString(R.string.starting)

        val serviceIntent = Intent(this, CutterService::class.java).apply {
            action = CutterService.ACTION_START
            putExtra(CutterService.EXTRA_URI, uri)
            putExtra(CutterService.EXTRA_DURATION_MS, videoDurationMs)
            putExtra(CutterService.EXTRA_BY_DURATION, byDuration)
            putExtra(CutterService.EXTRA_SECONDS_PER_CLIP, secondsPerClip ?: 0)
            putExtra(CutterService.EXTRA_CLIP_COUNT, clipCount ?: 0)
            putExtra(CutterService.EXTRA_RATIO, ratio)
        }
        ContextCompat.startForegroundService(this, serviceIntent)
    }

    private fun setUiBusy(busy: Boolean) {
        binding.btnCut.isEnabled = !busy
        binding.btnPickVideo.isEnabled = !busy
        binding.btnCancel.isEnabled = busy
        binding.progressBar.visibility = if (busy) android.view.View.VISIBLE else android.view.View.VISIBLE
    }

    private fun restorePrefs() {
        val byDuration = prefs.getBoolean("byDuration", true)
        binding.radioByDuration.isChecked = byDuration
        binding.radioByCount.isChecked = !byDuration
        binding.etSecondsPerClip.setText(prefs.getInt("seconds", 60).toString())
        binding.etClipCount.setText(prefs.getInt("count", 10).toString())
        binding.etSecondsPerClip.isEnabled = byDuration
        binding.etClipCount.isEnabled = !byDuration
        val ratioIdx = prefs.getInt("ratioIdx", 0)
        binding.spinnerRatio.setSelection(ratioIdx)
    }

    private fun savePrefs(byDuration: Boolean, seconds: Int?, count: Int?, ratio: String) {
        prefs.edit().apply {
            putBoolean("byDuration", byDuration)
            putInt("seconds", seconds ?: 60)
            putInt("count", count ?: 10)
            putInt("ratioIdx", binding.spinnerRatio.selectedItemPosition)
            apply()
        }
    }
}
