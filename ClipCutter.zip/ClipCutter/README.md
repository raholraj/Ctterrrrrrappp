# ClipCutter

Ek Android app jo 2-5 ghante ki lambi video ko chhote clips me kaat deti hai.

## Kaise build karein (GitHub Actions se APK)

1. Is poore `ClipCutter` folder ko ek naye GitHub repo me push karo (root me `.github/workflows/build-apk.yml` hona chahiye).
2. Repo ke "Actions" tab me jaake workflow ko manually run karo (ya `main` branch par push karte hi automatic chalega).
3. Build complete hone ke baad, "Artifacts" section me `ClipCutter-debug-apk` milega — usme APK hoga, download kar lo.
4. APK ko phone me install karo (Unknown sources allow karna padega).

## Kaise chalayein (agar Android Studio use karna ho)

`ClipCutter` folder ko Android Studio me "Open" karo, Gradle sync hone do, phir Run dabao.

## Features

- Bahut lambi video (2-5+ ghante) file picker se select karna, bina file ko copy kiye directly content:// URI se padhna
- Do cutting mode:
  - **Fixed seconds**: har clip kitne second ka hoga, aap batao
  - **Fixed count**: total kitne clips chahiye, aap batao — duration khud calculate ho jayega
- Output aspect ratio choose karna: Original, 16:9, 9:16 (Reels/Shorts ke liye), 1:1, 4:3
- Clips seedhe Movies/ClipCutter folder me MediaStore ke through save hote hain (Gallery me bhi dikhenge, internal storage me bhi milenge)
- Foreground service + notification progress bar, taaki app background me bhi crash na ho
- Cancel button — beech me process rok sakte ho
- Last used settings (seconds/count/ratio) automatically yaad rehti hain (SharedPreferences)
- Stream-copy mode (bina re-encode) jab ratio "Original" ho — bahut fast aur battery-friendly
- Sirf crop-wala ratio select karne par hi re-encode hota hai, wo bhi clip-by-clip (poori video kabhi RAM me nahi aati)

## Important note

`ffmpeg-kit` library (jo video cutting ke liye use hui hai) ka original maintainer (Arthenica) ne project ko 2025 me archive kar diya tha, lekin published Maven artifacts abhi bhi available hain aur normally kaam karte hain. Agar future me artifact hat jaaye to `com.arthenica:ffmpeg-kit-full-gpl` ki jagah kisi mirror (jaise `ffmpeg-kit-full-gpl` ka JitPack build) ya Media3 Transformer library use karni padegi.
